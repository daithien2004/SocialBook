(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__0gp8ifv._.css","static/chunks/MonTLCN_SocialBook_frontend_src_0s-u0k2._.js","static/chunks/0.ss_next_0nfvf60._.js","static/chunks/0.ss_@reduxjs_toolkit_dist_0n6g52l._.js","static/chunks/0.ss_axios_lib_05dg9ua._.js","static/chunks/0.ss_tailwind-merge_dist_bundle-mjs_mjs_00biset._.js","static/chunks/0.ss_react-hook-form_dist_index_esm_mjs_0.~q65d._.js","static/chunks/0.ss_zod_v4_0hwqg6w._.js","static/chunks/0.ss_@radix-ui_0ahk65t._.js","static/chunks/0.ss_@floating-ui_0~vfddf._.js","static/chunks/0.ss_0ozoh7k._.js"],
    source: "dynamic"
});
