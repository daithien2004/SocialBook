(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/MonTLCN/SocialBook/frontend/src/components/notification/NotificationBell.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/0.ss_031k4n_._.js",
  "static/chunks/MonTLCN_SocialBook_frontend_src_0w4vg1b._.js",
  "static/chunks/0fl1_SocialBook_frontend_src_components_notification_NotificationBell_tsx_0w_h9gp._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/MonTLCN/SocialBook/frontend/src/components/notification/NotificationBell.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
"[project]/MonTLCN/SocialBook/frontend/src/components/chat/ChatWidget.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/MonTLCN_SocialBook_frontend_0jnc5x6._.js",
  "static/chunks/MonTLCN_SocialBook_frontend_src_components_chat_ChatWidget_tsx_0w_h9gp._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/MonTLCN/SocialBook/frontend/src/components/chat/ChatWidget.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
]);