(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/MonTLCN_SocialBook_frontend_src_components_049cd-1._.js","static/chunks/MonTLCN_SocialBook_frontend_0~sw2bz._.js"],
    source: "dynamic"
});
