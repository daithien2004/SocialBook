(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/MonTLCN/SocialBook/frontend/src/components/common/SafeImage.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SafeImage",
    ()=>SafeImage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/node_modules/next/image.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
const DEFAULT_FALLBACK = 'https://images.unsplash.com/photo-1541963463532-d68292c34b19?q=80&w=1000&auto=format&fit=crop';
const SafeImage = ({ src, fallbackSrc = DEFAULT_FALLBACK, alt, ...props })=>{
    _s();
    const [imgSrc, setImgSrc] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(src);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SafeImage.useEffect": ()=>{
            setImgSrc(src);
            setError(false);
        }
    }["SafeImage.useEffect"], [
        src
    ]);
    // Handle known bad domains immediately if needed
    const isBadDomain = typeof src === 'string' && src.includes('nhasachmienphi.com');
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        ...props,
        src: error || isBadDomain ? fallbackSrc : imgSrc,
        alt: alt,
        onError: ()=>{
            setError(true);
        }
    }, void 0, false, {
        fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/common/SafeImage.tsx",
        lineNumber: 25,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(SafeImage, "tptPopfnfZ9+JnDxGNizzz/BdQw=");
_c = SafeImage;
var _c;
__turbopack_context__.k.register(_c, "SafeImage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/MonTLCN/SocialBook/frontend/src/components/ui/badge.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Badge",
    ()=>Badge,
    "badgeVariants",
    ()=>badgeVariants
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/node_modules/class-variance-authority/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/src/lib/utils.ts [app-client] (ecmascript)");
;
;
;
const badgeVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("inline-flex items-center rounded-md border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2", {
    variants: {
        variant: {
            default: "border-transparent bg-primary text-primary-foreground shadow hover:bg-primary/80",
            secondary: "border-transparent bg-secondary text-secondary-foreground hover:bg-secondary/80",
            destructive: "border-transparent bg-destructive text-destructive-foreground shadow hover:bg-destructive/80",
            outline: "text-foreground"
        }
    },
    defaultVariants: {
        variant: "default"
    }
});
function Badge({ className, variant, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])(badgeVariants({
            variant
        }), className),
        ...props
    }, void 0, false, {
        fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/ui/badge.tsx",
        lineNumber: 32,
        columnNumber: 5
    }, this);
}
_c = Badge;
;
var _c;
__turbopack_context__.k.register(_c, "Badge");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/MonTLCN/SocialBook/frontend/src/components/ui/card.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Card",
    ()=>Card,
    "CardContent",
    ()=>CardContent,
    "CardDescription",
    ()=>CardDescription,
    "CardFooter",
    ()=>CardFooter,
    "CardHeader",
    ()=>CardHeader,
    "CardTitle",
    ()=>CardTitle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/src/lib/utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
;
;
const Card = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('rounded-xl border-0 bg-card shadow', className),
        ...props
    }, void 0, false, {
        fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/ui/card.tsx",
        lineNumber: 8,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
_c1 = Card;
Card.displayName = 'Card';
const CardHeader = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c2 = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('flex flex-col space-y-1.5 p-6', className),
        ...props
    }, void 0, false, {
        fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/ui/card.tsx",
        lineNumber: 20,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
_c3 = CardHeader;
CardHeader.displayName = 'CardHeader';
const CardTitle = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c4 = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('font-semibold leading-none tracking-tight', className),
        ...props
    }, void 0, false, {
        fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/ui/card.tsx",
        lineNumber: 32,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
_c5 = CardTitle;
CardTitle.displayName = 'CardTitle';
const CardDescription = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c6 = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('text-sm text-muted-foreground', className),
        ...props
    }, void 0, false, {
        fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/ui/card.tsx",
        lineNumber: 44,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
_c7 = CardDescription;
CardDescription.displayName = 'CardDescription';
const CardContent = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c8 = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('p-6 pt-0', className),
        ...props
    }, void 0, false, {
        fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/ui/card.tsx",
        lineNumber: 56,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
_c9 = CardContent;
CardContent.displayName = 'CardContent';
const CardFooter = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c10 = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('flex items-center p-6 pt-0', className),
        ...props
    }, void 0, false, {
        fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/ui/card.tsx",
        lineNumber: 64,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
_c11 = CardFooter;
CardFooter.displayName = 'CardFooter';
;
var _c, _c1, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10, _c11;
__turbopack_context__.k.register(_c, "Card$React.forwardRef");
__turbopack_context__.k.register(_c1, "Card");
__turbopack_context__.k.register(_c2, "CardHeader$React.forwardRef");
__turbopack_context__.k.register(_c3, "CardHeader");
__turbopack_context__.k.register(_c4, "CardTitle$React.forwardRef");
__turbopack_context__.k.register(_c5, "CardTitle");
__turbopack_context__.k.register(_c6, "CardDescription$React.forwardRef");
__turbopack_context__.k.register(_c7, "CardDescription");
__turbopack_context__.k.register(_c8, "CardContent$React.forwardRef");
__turbopack_context__.k.register(_c9, "CardContent");
__turbopack_context__.k.register(_c10, "CardFooter$React.forwardRef");
__turbopack_context__.k.register(_c11, "CardFooter");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/MonTLCN/SocialBook/frontend/src/components/book/BookCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BookCard",
    ()=>BookCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bookmark$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Bookmark$3e$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/node_modules/lucide-react/dist/esm/icons/bookmark.js [app-client] (ecmascript) <export default as Bookmark>");
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$components$2f$common$2f$SafeImage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/src/components/common/SafeImage.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$components$2f$ui$2f$badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/src/components/ui/badge.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/src/components/ui/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/src/components/ui/card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/src/lib/utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$store$2f$useModalStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/src/store/useModalStore.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
const BookCard = /*#__PURE__*/ _s((0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(_c = _s(function BookCard({ book }) {
    _s();
    const { openAddToLibrary, isAddToLibraryOpen, addToLibraryData } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$store$2f$useModalStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useModalStore"])();
    const isCurrentBookOpen = isAddToLibraryOpen && addToLibraryData?.bookId === book.id;
    const handleAddToLibrary = (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "BookCard.BookCard.useCallback[handleAddToLibrary]": (e)=>{
            e.preventDefault();
            e.stopPropagation();
            openAddToLibrary({
                bookId: book.id
            });
        }
    }["BookCard.BookCard.useCallback[handleAddToLibrary]"], [
        book.id,
        openAddToLibrary
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            href: `/books/${book.slug}`,
            className: "group relative block w-full max-w-[220px]",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Card"], {
                className: "overflow-hidden border-gray-200 dark:border-white/10 transition-all duration-500 hover:border-gray-400 dark:hover:border-white/30 hover:shadow-lg dark:hover:shadow-[0_0_30px_rgba(255,255,255,0.05)] bg-card text-card-foreground",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BookCover, {
                        book: book
                    }, void 0, false, {
                        fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/BookCard.tsx",
                        lineNumber: 35,
                        columnNumber: 21
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardContent"], {
                        className: "flex flex-col p-4 pt-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BookInfo, {
                                book: book
                            }, void 0, false, {
                                fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/BookCard.tsx",
                                lineNumber: 37,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BookStats, {
                                book: book,
                                handleAddToLibrary: handleAddToLibrary,
                                isCurrentBookOpen: isCurrentBookOpen
                            }, void 0, false, {
                                fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/BookCard.tsx",
                                lineNumber: 38,
                                columnNumber: 25
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/BookCard.tsx",
                        lineNumber: 36,
                        columnNumber: 21
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/BookCard.tsx",
                lineNumber: 34,
                columnNumber: 17
            }, this)
        }, void 0, false, {
            fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/BookCard.tsx",
            lineNumber: 30,
            columnNumber: 13
        }, this)
    }, void 0, false);
}, "g3Vedww2iVV5Ea8kMqlf/Lo3HFk=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$store$2f$useModalStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useModalStore"]
    ];
})), "g3Vedww2iVV5Ea8kMqlf/Lo3HFk=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$store$2f$useModalStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useModalStore"]
    ];
});
_c1 = BookCard;
function BookCover({ book }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "relative aspect-[2/3] w-full overflow-hidden",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$components$2f$common$2f$SafeImage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SafeImage"], {
                src: book.coverUrl,
                alt: book.title,
                fill: true,
                sizes: "(max-width: 768px) 160px, 220px",
                className: "object-cover opacity-90 transition-all duration-700 group-hover:scale-105 group-hover:opacity-100 group-hover:contrast-125"
            }, void 0, false, {
                fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/BookCard.tsx",
                lineNumber: 49,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute inset-0 bg-gradient-to-t from-background/90 via-transparent to-transparent opacity-80"
            }, void 0, false, {
                fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/BookCard.tsx",
                lineNumber: 57,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute top-3 w-full text-center",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$components$2f$ui$2f$badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Badge"], {
                    variant: "secondary",
                    className: "text-[9px] font-bold tracking-[0.3em] uppercase bg-background/80 backdrop-blur-sm border-none shadow-sm",
                    children: book.status === 'published' ? 'COMING SOON' : 'IN PRODUCTION'
                }, void 0, false, {
                    fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/BookCard.tsx",
                    lineNumber: 60,
                    columnNumber: 17
                }, this)
            }, void 0, false, {
                fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/BookCard.tsx",
                lineNumber: 59,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/BookCard.tsx",
        lineNumber: 48,
        columnNumber: 9
    }, this);
}
_c2 = BookCover;
function BookInfo({ book }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "mb-1 text-center",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-[10px] font-medium tracking-[0.2em] uppercase text-muted-foreground group-hover:text-foreground transition-colors",
                children: book.authorId.name
            }, void 0, false, {
                fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/BookCard.tsx",
                lineNumber: 71,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                className: "mb-4 text-center text-sm font-notosans font-semibold text-foreground bg-clip-text group-hover:text-red-600 dark:group-hover:text-white group-hover:drop-shadow-[0_0_8px_rgba(239,68,68,0.5)] dark:group-hover:drop-shadow-[0_0_8px_rgba(255,255,255,0.5)] transition-all line-clamp-2",
                children: book.title
            }, void 0, false, {
                fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/BookCard.tsx",
                lineNumber: 74,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/BookCard.tsx",
        lineNumber: 70,
        columnNumber: 9
    }, this);
}
_c3 = BookInfo;
function BookStats({ book, handleAddToLibrary, isCurrentBookOpen }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "mt-auto flex items-center justify-between border-t border-border pt-3",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-2 text-[11px] font-mono font-bold text-muted-foreground",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: [
                            "VOL ",
                            book.stats?.chapterCount || 0
                        ]
                    }, void 0, true, {
                        fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/BookCard.tsx",
                        lineNumber: 91,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "relative flex h-2 w-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "animate-ping absolute inline-flex h-full w-full rounded-full bg-red-600 opacity-75"
                            }, void 0, false, {
                                fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/BookCard.tsx",
                                lineNumber: 94,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "relative inline-flex rounded-full h-2 w-2 bg-red-600"
                            }, void 0, false, {
                                fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/BookCard.tsx",
                                lineNumber: 95,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/BookCard.tsx",
                        lineNumber: 93,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "flex items-center gap-1",
                        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatCompact"])(book.stats?.views || 0)
                    }, void 0, false, {
                        fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/BookCard.tsx",
                        lineNumber: 98,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/BookCard.tsx",
                lineNumber: 90,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                variant: "ghost",
                size: "icon",
                "aria-label": "Thêm vào danh sách đọc",
                onClick: handleAddToLibrary,
                className: "h-8 w-8 text-muted-foreground hover:text-red-600 dark:hover:text-white hover:bg-transparent",
                title: "Save to Library",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bookmark$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Bookmark$3e$__["Bookmark"], {
                    size: 16,
                    className: "transition-transform hover:scale-110",
                    fill: isCurrentBookOpen ? 'currentColor' : 'none'
                }, void 0, false, {
                    fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/BookCard.tsx",
                    lineNumber: 111,
                    columnNumber: 17
                }, this)
            }, void 0, false, {
                fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/BookCard.tsx",
                lineNumber: 103,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/BookCard.tsx",
        lineNumber: 89,
        columnNumber: 9
    }, this);
}
_c4 = BookStats;
var _c, _c1, _c2, _c3, _c4;
__turbopack_context__.k.register(_c, "BookCard$memo");
__turbopack_context__.k.register(_c1, "BookCard");
__turbopack_context__.k.register(_c2, "BookCover");
__turbopack_context__.k.register(_c3, "BookInfo");
__turbopack_context__.k.register(_c4, "BookStats");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/MonTLCN/SocialBook/frontend/src/features/books/hooks/useBookParams.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useBookParams",
    ()=>useBookParams
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
const useBookParams = ()=>{
    _s();
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const genres = (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useBookParams.useMemo[genres]": ()=>searchParams.get('genres')?.split(',').filter(Boolean) || []
    }["useBookParams.useMemo[genres]"], [
        searchParams
    ]);
    const tags = (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useBookParams.useMemo[tags]": ()=>searchParams.get('tags')?.split(',').filter(Boolean) || []
    }["useBookParams.useMemo[tags]"], [
        searchParams
    ]);
    const searchQuery = searchParams.get('search') || '';
    // When searching, default to 'score' for relevance; when browsing, default to 'createdAt'
    const defaultSort = searchQuery ? 'score' : 'createdAt';
    const sortBy = searchParams.get('sortBy') || defaultSort;
    const order = searchParams.get('order') || 'desc';
    const updateParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useBookParams.useCallback[updateParams]": (updates)=>{
            const params = new URLSearchParams(searchParams.toString());
            Object.entries(updates).forEach({
                "useBookParams.useCallback[updateParams]": ([key, value])=>{
                    if (value) params.set(key, value);
                    else params.delete(key);
                }
            }["useBookParams.useCallback[updateParams]"]);
            router.push(`${pathname}?${params.toString()}`, {
                scroll: false
            });
        }
    }["useBookParams.useCallback[updateParams]"], [
        searchParams,
        pathname,
        router
    ]);
    const toggleFilter = (type, slug)=>{
        const currentList = type === 'genres' ? genres : tags;
        const newList = currentList.includes(slug) ? currentList.filter((item)=>item !== slug) : [
            ...currentList,
            slug
        ];
        updateParams({
            [type]: newList.length > 0 ? newList.join(',') : null
        });
    };
    const setSort = (sortValue, sortOrder)=>{
        updateParams({
            sortBy: sortValue,
            order: sortOrder
        });
    };
    const setSearch = (term)=>{
        updateParams({
            search: term.trim() || null
        });
    };
    const clearFilters = ()=>updateParams({
            genres: null,
            tags: null
        });
    const clearGenres = ()=>updateParams({
            genres: null
        });
    const clearTags = ()=>updateParams({
            tags: null
        });
    const clearSearch = ()=>updateParams({
            search: null
        });
    const clearAll = ()=>router.push(pathname);
    return {
        genres,
        tags,
        searchQuery,
        sortBy,
        order,
        toggleFilter,
        setSort,
        setSearch,
        clearFilters,
        clearGenres,
        clearTags,
        clearSearch,
        clearAll
    };
};
_s(useBookParams, "m6KrQlUabvoaZ05OLwq8pn5HAmo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"],
        __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/MonTLCN/SocialBook/frontend/src/features/books/hooks/useBookPagination.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useBookPagination",
    ()=>useBookPagination
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$features$2f$books$2f$api$2f$bookApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/src/features/books/api/bookApi.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
const useBookPagination = (params)=>{
    _s();
    const [page, setPage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    const [allBooks, setAllBooks] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [hasMore, setHasMore] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const queryKey = JSON.stringify({
        ...params
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useBookPagination.useEffect": ()=>{
            setPage(1);
            setAllBooks([]);
            setHasMore(true);
        }
    }["useBookPagination.useEffect"], [
        queryKey
    ]);
    const { data, isLoading, isFetching } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$features$2f$books$2f$api$2f$bookApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGetBooksQuery"])({
        page,
        limit: 20,
        search: params.search,
        genres: params.genres.join(','),
        tags: params.tags.join(','),
        sortBy: params.sortBy,
        order: params.order
    }, {
        refetchOnMountOrArgChange: true
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useBookPagination.useEffect": ()=>{
            if (data?.data) {
                if (page === 1) {
                    setAllBooks(data.data);
                } else {
                    setAllBooks({
                        "useBookPagination.useEffect": (prev)=>{
                            const existingIds = new Set(prev.map({
                                "useBookPagination.useEffect": (b)=>b.id
                            }["useBookPagination.useEffect"]));
                            const uniqueNewBooks = data.data.filter({
                                "useBookPagination.useEffect.uniqueNewBooks": (b)=>!existingIds.has(b.id)
                            }["useBookPagination.useEffect.uniqueNewBooks"]);
                            return [
                                ...prev,
                                ...uniqueNewBooks
                            ];
                        }
                    }["useBookPagination.useEffect"]);
                }
                setHasMore(data.meta.current < data.meta.totalPages);
            } else if (!isLoading && !isFetching && page > 1) {
                setHasMore(false);
            }
        }
    }["useBookPagination.useEffect"], [
        data,
        page,
        isLoading,
        isFetching
    ]);
    // Logic Infinite Scroll (Intersection Observer)
    const observer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const lastBookRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useBookPagination.useCallback[lastBookRef]": (node)=>{
            if (isFetching) return;
            if (observer.current) observer.current.disconnect();
            observer.current = new IntersectionObserver({
                "useBookPagination.useCallback[lastBookRef]": (entries)=>{
                    if (entries[0].isIntersecting && hasMore) {
                        setPage({
                            "useBookPagination.useCallback[lastBookRef]": (prev)=>prev + 1
                        }["useBookPagination.useCallback[lastBookRef]"]);
                    }
                }
            }["useBookPagination.useCallback[lastBookRef]"]);
            if (node) observer.current.observe(node);
        }
    }["useBookPagination.useCallback[lastBookRef]"], [
        isFetching,
        hasMore
    ]);
    return {
        books: allBooks,
        isLoading: isLoading && page === 1,
        isFetchingMore: isFetching && page > 1,
        hasMore,
        lastBookRef,
        metaData: data?.meta
    };
};
_s(useBookPagination, "she5Kvfjvy34HtHZdASQwKJf1z4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$features$2f$books$2f$api$2f$bookApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGetBooksQuery"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/MonTLCN/SocialBook/frontend/src/components/book/SearchBar.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SearchBar",
    ()=>SearchBar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/node_modules/lucide-react/dist/esm/icons/x.js [app-client] (ecmascript) <export default as X>");
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
const SearchBar = ({ initialValue, onSearch, onClear, debounceMs = 500 })=>{
    _s();
    const [input, setInput] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialValue);
    const debounceRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const isComposing = (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    const lastSearchedValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(initialValue);
    // Sync khi URL thay đổi từ bên ngoài (nhưng bỏ qua nếu do chính mình vừa search)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SearchBar.useEffect": ()=>{
            // So sánh đã trim() để tránh việc URL (thường bị trim) ghi đè mất dấu cách cuối câu người dùng đang gõ
            const normalizedInitial = initialValue.trim();
            const normalizedLast = lastSearchedValue.current.trim();
            if (normalizedInitial !== normalizedLast) {
                setInput(initialValue);
                lastSearchedValue.current = initialValue;
            }
        }
    }["SearchBar.useEffect"], [
        initialValue
    ]);
    // Cleanup debounce on unmount
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SearchBar.useEffect": ()=>{
            return ({
                "SearchBar.useEffect": ()=>{
                    if (debounceRef.current) {
                        clearTimeout(debounceRef.current);
                    }
                }
            })["SearchBar.useEffect"];
        }
    }["SearchBar.useEffect"], []);
    // Debounced search handler
    const handleInputChange = (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "SearchBar.useCallback[handleInputChange]": (value)=>{
            setInput(value);
            if (isComposing.current) return;
            // Clear previous timeout
            if (debounceRef.current) {
                clearTimeout(debounceRef.current);
            }
            // Set new timeout for debounced search
            debounceRef.current = setTimeout({
                "SearchBar.useCallback[handleInputChange]": ()=>{
                    if (value.trim()) {
                        onSearch(value);
                        lastSearchedValue.current = value;
                    } else {
                        onClear();
                        lastSearchedValue.current = '';
                    }
                }
            }["SearchBar.useCallback[handleInputChange]"], debounceMs);
        }
    }["SearchBar.useCallback[handleInputChange]"], [
        onSearch,
        debounceMs
    ]);
    const handleCompositionStart = ()=>{
        isComposing.current = true;
    };
    const handleCompositionEnd = (e)=>{
        isComposing.current = false;
        // Trigger search immediately after composition ends (optional, or wait for next debounce)
        const value = e.currentTarget.value;
        // Clear previous timeout to maintain consistent debounce behavior
        if (debounceRef.current) {
            clearTimeout(debounceRef.current);
        }
        debounceRef.current = setTimeout(()=>{
            if (value.trim()) {
                onSearch(value);
                lastSearchedValue.current = value;
            } else {
                onClear();
                lastSearchedValue.current = '';
            }
        }, debounceMs);
    };
    const handleSubmit = (e)=>{
        e.preventDefault();
        // Clear debounce and search immediately on submit
        if (debounceRef.current) {
            clearTimeout(debounceRef.current);
        }
        onSearch(input);
        lastSearchedValue.current = input;
    };
    const handleClear = ()=>{
        if (debounceRef.current) {
            clearTimeout(debounceRef.current);
        }
        setInput('');
        onClear();
        lastSearchedValue.current = '';
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
        onSubmit: handleSubmit,
        className: "mb-10 max-w-3xl mx-auto relative group",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                type: "text",
                value: input,
                onChange: (e)=>handleInputChange(e.target.value),
                onCompositionStart: handleCompositionStart,
                onCompositionEnd: handleCompositionEnd,
                placeholder: "Tìm kiếm tên truyện, tác giả...",
                className: "block w-full pl-5 pr-12 py-4 rounded-full bg-white dark:bg-white/5 border border-gray-300 dark:border-white/10 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-red-600/50 shadow-lg backdrop-blur-sm transition-all"
            }, void 0, false, {
                fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/SearchBar.tsx",
                lineNumber: 116,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            (input || initialValue) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                onClick: handleClear,
                className: "absolute inset-y-0 right-4 flex items-center text-gray-400 hover:text-red-500 transition-colors",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                    size: 20
                }, void 0, false, {
                    fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/SearchBar.tsx",
                    lineNumber: 131,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/SearchBar.tsx",
                lineNumber: 126,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/SearchBar.tsx",
        lineNumber: 112,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(SearchBar, "/YpWxrUi6g7JZmawNTaZchIe2yU=");
_c = SearchBar;
var _c;
__turbopack_context__.k.register(_c, "SearchBar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/MonTLCN/SocialBook/frontend/src/components/book/FilterSection.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FilterSection",
    ()=>FilterSection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/src/lib/utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$components$2f$ui$2f$badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/src/components/ui/badge.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/src/components/ui/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/src/components/ui/card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$funnel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Filter$3e$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/node_modules/lucide-react/dist/esm/icons/funnel.js [app-client] (ecmascript) <export default as Filter>");
'use client';
;
;
;
;
;
;
const FilterSection = ({ allGenres, allTags, selectedGenres, selectedTags, onToggleGenre, onToggleTag, onClearGenres })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Card"], {
        className: "border-gray-100 dark:border-white/10 shadow-sm",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardHeader"], {
                className: "pb-3 border-b border-gray-100 dark:border-white/5",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardTitle"], {
                    className: "text-sm font-bold uppercase tracking-wider flex items-center gap-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$funnel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Filter$3e$__["Filter"], {
                            size: 16,
                            className: "text-red-500"
                        }, void 0, false, {
                            fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/FilterSection.tsx",
                            lineNumber: 32,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        "Bộ lọc"
                    ]
                }, void 0, true, {
                    fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/FilterSection.tsx",
                    lineNumber: 31,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/FilterSection.tsx",
                lineNumber: 30,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardContent"], {
                className: "space-y-6 pt-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-2 mb-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: "text-xs font-bold uppercase tracking-wider text-muted-foreground",
                                        children: "Thể loại"
                                    }, void 0, false, {
                                        fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/FilterSection.tsx",
                                        lineNumber: 41,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    selectedGenres.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$components$2f$ui$2f$badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Badge"], {
                                        variant: "secondary",
                                        className: "text-[10px] h-5 px-1.5",
                                        children: selectedGenres.length
                                    }, void 0, false, {
                                        fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/FilterSection.tsx",
                                        lineNumber: 45,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/FilterSection.tsx",
                                lineNumber: 40,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-wrap gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                        variant: selectedGenres.length === 0 ? "default" : "outline",
                                        size: "sm",
                                        onClick: onClearGenres,
                                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("h-8 transition-all", selectedGenres.length === 0 ? "bg-red-600 hover:bg-red-700 text-white border-transparent" : "bg-transparent text-muted-foreground hover:text-foreground"),
                                        children: "Tất cả"
                                    }, void 0, false, {
                                        fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/FilterSection.tsx",
                                        lineNumber: 51,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    allGenres?.map((genre)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                            variant: selectedGenres.includes(genre.slug) ? "default" : "outline",
                                            size: "sm",
                                            onClick: ()=>onToggleGenre(genre.slug),
                                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("h-8 transition-all", selectedGenres.includes(genre.slug) ? "bg-red-600 hover:bg-red-700 text-white border-transparent" : "bg-transparent text-muted-foreground hover:text-foreground hover:bg-accent"),
                                            children: [
                                                genre.name,
                                                genre.count > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("ml-1.5 text-xs opacity-60", selectedGenres.includes(genre.slug) ? "text-white/80" : "text-muted-foreground"),
                                                    children: [
                                                        "(",
                                                        genre.count,
                                                        ")"
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/FilterSection.tsx",
                                                    lineNumber: 79,
                                                    columnNumber: 19
                                                }, ("TURBOPACK compile-time value", void 0))
                                            ]
                                        }, genre.id, true, {
                                            fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/FilterSection.tsx",
                                            lineNumber: 65,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0)))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/FilterSection.tsx",
                                lineNumber: 50,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/FilterSection.tsx",
                        lineNumber: 39,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    allTags?.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                className: "text-xs font-bold uppercase tracking-wider text-muted-foreground mb-3 border-t border-dashed border-gray-200 dark:border-white/10 pt-4",
                                children: "Tags phổ biến"
                            }, void 0, false, {
                                fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/FilterSection.tsx",
                                lineNumber: 96,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-wrap gap-2",
                                children: allTags.map((tag)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$components$2f$ui$2f$badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Badge"], {
                                        variant: selectedTags.includes(tag.name) ? "default" : "outline",
                                        onClick: ()=>onToggleTag(tag.name),
                                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("cursor-pointer px-3 py-1 text-xs transition-all hover:border-foreground/50", selectedTags.includes(tag.name) ? "bg-foreground text-background hover:bg-foreground/90 border-transparent" : "text-muted-foreground hover:text-foreground"),
                                        children: [
                                            "#",
                                            tag.name,
                                            ' ',
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "ml-1 opacity-60",
                                                children: [
                                                    "(",
                                                    tag.count,
                                                    ")"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/FilterSection.tsx",
                                                lineNumber: 113,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, tag.name, true, {
                                        fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/FilterSection.tsx",
                                        lineNumber: 101,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0)))
                            }, void 0, false, {
                                fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/FilterSection.tsx",
                                lineNumber: 99,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/FilterSection.tsx",
                        lineNumber: 95,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/FilterSection.tsx",
                lineNumber: 37,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/FilterSection.tsx",
        lineNumber: 29,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c = FilterSection;
var _c;
__turbopack_context__.k.register(_c, "FilterSection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/MonTLCN/SocialBook/frontend/src/features/books/books.constants.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DEFAULT_SORT",
    ()=>DEFAULT_SORT,
    "GRID_COLUMNS",
    ()=>GRID_COLUMNS,
    "PAGINATION",
    ()=>PAGINATION,
    "SORT_OPTIONS",
    ()=>SORT_OPTIONS,
    "TABS",
    ()=>TABS,
    "TAB_CONFIG",
    ()=>TAB_CONFIG
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$flame$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Flame$3e$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/node_modules/lucide-react/dist/esm/icons/flame.js [app-client] (ecmascript) <export default as Flame>");
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$sparkles$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Sparkles$3e$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/node_modules/lucide-react/dist/esm/icons/sparkles.js [app-client] (ecmascript) <export default as Sparkles>");
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$book$2d$plus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BookPlus$3e$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/node_modules/lucide-react/dist/esm/icons/book-plus.js [app-client] (ecmascript) <export default as BookPlus>");
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$star$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Star$3e$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/node_modules/lucide-react/dist/esm/icons/star.js [app-client] (ecmascript) <export default as Star>");
;
const PAGINATION = {
    BOOKS_PER_PAGE: 20,
    FEATURED_BOOKS_COUNT: 5,
    SCROLL_THRESHOLD: '200px'
};
const GRID_COLUMNS = {
    MOBILE: 2,
    SM: 3,
    MD: 4,
    LG: 5,
    XL: 6
};
const TAB_CONFIG = {
    TRENDING: {
        id: 'trending',
        label: 'Hot nhất',
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$flame$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Flame$3e$__["Flame"],
        sortBy: 'views'
    },
    NEW: {
        id: 'new',
        label: 'Mới nhất',
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$book$2d$plus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BookPlus$3e$__["BookPlus"],
        sortBy: 'createdAt'
    },
    TOP_RATED: {
        id: 'topRated',
        label: 'Đánh giá cao',
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$star$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Star$3e$__["Star"],
        sortBy: 'likes'
    },
    UPDATED: {
        id: 'updated',
        label: 'Mới cập nhật',
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$sparkles$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Sparkles$3e$__["Sparkles"],
        sortBy: 'updatedAt'
    }
};
const TABS = Object.values(TAB_CONFIG);
_c = TABS;
const SORT_OPTIONS = [
    {
        value: 'score',
        order: 'desc',
        label: 'Phù hợp nhất'
    },
    {
        value: 'createdAt',
        order: 'desc',
        label: 'Mới nhất'
    },
    {
        value: 'updatedAt',
        order: 'desc',
        label: 'Mới cập nhật'
    },
    {
        value: 'createdAt',
        order: 'asc',
        label: 'Cũ nhất'
    },
    {
        value: 'views',
        order: 'desc',
        label: 'Đọc nhiều nhất'
    },
    {
        value: 'rating',
        order: 'desc',
        label: 'Đánh giá cao'
    },
    {
        value: 'likes',
        order: 'desc',
        label: 'Yêu thích nhất'
    }
];
const DEFAULT_SORT = {
    value: 'createdAt',
    order: 'desc',
    label: 'Mới nhất'
};
var _c;
__turbopack_context__.k.register(_c, "TABS");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/MonTLCN/SocialBook/frontend/src/components/book/SortDropdown.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SortDropdown",
    ()=>SortDropdown
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/src/components/ui/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/src/components/ui/dropdown-menu.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/src/lib/utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$features$2f$books$2f$books$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/src/features/books/books.constants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/node_modules/lucide-react/dist/esm/icons/chevron-down.js [app-client] (ecmascript) <export default as ChevronDown>");
'use client';
;
;
;
;
;
;
const SortDropdown = ({ currentSort, currentOrder, onSortChange })=>{
    const activeLabel = __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$features$2f$books$2f$books$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SORT_OPTIONS"].find((s)=>s.value === currentSort && s.order === currentOrder)?.label || 'Sắp xếp';
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "lg:w-64 flex-shrink-0",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                className: "text-sm font-bold uppercase tracking-wider text-muted-foreground mb-3",
                children: "Sắp xếp theo"
            }, void 0, false, {
                fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/SortDropdown.tsx",
                lineNumber: 31,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenu"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuTrigger"], {
                        asChild: true,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                            variant: "outline",
                            className: "w-full justify-between bg-background border-input hover:bg-accent hover:text-accent-foreground font-normal",
                            children: [
                                activeLabel,
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__["ChevronDown"], {
                                    className: "ml-2 h-4 w-4 opacity-50"
                                }, void 0, false, {
                                    fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/SortDropdown.tsx",
                                    lineNumber: 41,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/SortDropdown.tsx",
                            lineNumber: 36,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/SortDropdown.tsx",
                        lineNumber: 35,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuContent"], {
                        className: "w-[--radix-dropdown-menu-trigger-width]",
                        align: "start",
                        children: __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$features$2f$books$2f$books$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SORT_OPTIONS"].map((option)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuItem"], {
                                onClick: ()=>onSortChange(option.value, option.order),
                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("cursor-pointer", currentSort === option.value && currentOrder === option.order ? "bg-red-50 text-red-600 focus:bg-red-50 focus:text-red-600 dark:bg-red-900/20 dark:text-red-400 dark:focus:bg-red-900/30" : ""),
                                children: option.label
                            }, `${option.value}-${option.order}`, false, {
                                fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/SortDropdown.tsx",
                                lineNumber: 46,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)))
                    }, void 0, false, {
                        fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/SortDropdown.tsx",
                        lineNumber: 44,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/SortDropdown.tsx",
                lineNumber: 34,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/SortDropdown.tsx",
        lineNumber: 30,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c = SortDropdown;
var _c;
__turbopack_context__.k.register(_c, "SortDropdown");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/MonTLCN/SocialBook/frontend/src/components/book/ActiveFilters.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ActiveFilters",
    ()=>ActiveFilters
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/node_modules/lucide-react/dist/esm/icons/x.js [app-client] (ecmascript) <export default as X>");
'use client';
;
;
const ActiveFilters = ({ genres, tags, allGenres, onRemoveGenre, onRemoveTag, onClearAll })=>{
    if (genres.length === 0 && tags.length === 0) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex items-center gap-3 mb-6 pb-4 border-b border-gray-200 dark:border-white/5 overflow-x-auto scrollbar-hide",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-xs text-gray-500 uppercase font-bold whitespace-nowrap",
                children: "Đang lọc:"
            }, void 0, false, {
                fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/ActiveFilters.tsx",
                lineNumber: 27,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            genres.map((slug)=>{
                const name = allGenres?.find((g)=>g.slug === slug)?.name || slug;
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-1 px-2 py-1 bg-red-500/10 border border-red-500/30 text-red-600 dark:text-red-400 text-xs rounded hover:bg-red-500/20 transition-colors",
                    children: [
                        name,
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>onRemoveGenre(slug),
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                size: 12
                            }, void 0, false, {
                                fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/ActiveFilters.tsx",
                                lineNumber: 40,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/ActiveFilters.tsx",
                            lineNumber: 39,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, slug, true, {
                    fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/ActiveFilters.tsx",
                    lineNumber: 34,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0));
            }),
            tags.map((tag)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-1 px-2 py-1 bg-gray-200 dark:bg-white/10 border border-gray-300 dark:border-white/20 text-gray-700 dark:text-gray-300 text-xs rounded hover:bg-gray-300 transition-colors",
                    children: [
                        "#",
                        tag,
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>onRemoveTag(tag),
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                size: 12
                            }, void 0, false, {
                                fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/ActiveFilters.tsx",
                                lineNumber: 53,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/ActiveFilters.tsx",
                            lineNumber: 52,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, tag, true, {
                    fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/ActiveFilters.tsx",
                    lineNumber: 47,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: onClearAll,
                className: "text-xs text-gray-500 hover:text-red-600 underline whitespace-nowrap ml-auto",
                children: "Xóa bộ lọc"
            }, void 0, false, {
                fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/ActiveFilters.tsx",
                lineNumber: 58,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/MonTLCN/SocialBook/frontend/src/components/book/ActiveFilters.tsx",
        lineNumber: 26,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c = ActiveFilters;
var _c;
__turbopack_context__.k.register(_c, "ActiveFilters");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/MonTLCN/SocialBook/frontend/src/app/(user)/books/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>BooksPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$features$2f$books$2f$api$2f$bookApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/src/features/books/api/bookApi.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$components$2f$book$2f$BookCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/src/components/book/BookCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/node_modules/lucide-react/dist/esm/icons/search.js [app-client] (ecmascript) <export default as Search>");
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$features$2f$books$2f$hooks$2f$useBookParams$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/src/features/books/hooks/useBookParams.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$features$2f$books$2f$hooks$2f$useBookPagination$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/src/features/books/hooks/useBookPagination.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$components$2f$book$2f$SearchBar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/src/components/book/SearchBar.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$components$2f$book$2f$FilterSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/src/components/book/FilterSection.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$components$2f$book$2f$SortDropdown$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/src/components/book/SortDropdown.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$components$2f$book$2f$ActiveFilters$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/MonTLCN/SocialBook/frontend/src/components/book/ActiveFilters.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
;
function BooksPage() {
    _s();
    const { genres, tags, searchQuery, sortBy, order, toggleFilter, setSort, setSearch, clearSearch, clearFilters, clearAll, clearGenres } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$features$2f$books$2f$hooks$2f$useBookParams$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBookParams"])();
    const { data: filtersData, isLoading: isFiltersLoading } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$features$2f$books$2f$api$2f$bookApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGetFiltersQuery"])();
    const { books, isLoading: isBooksLoading, isFetchingMore, hasMore, lastBookRef, metaData } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$features$2f$books$2f$hooks$2f$useBookPagination$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBookPagination"])({
        search: searchQuery,
        genres,
        tags,
        sortBy,
        order
    });
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-screen bg-gray-50 dark:bg-[#161515] text-gray-900 dark:text-gray-100 relative transition-colors duration-300",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "fixed inset-0 z-0 pointer-events-none",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        src: "/main-background.jpg",
                        alt: "Background",
                        fill: true,
                        priority: true,
                        sizes: "100vw",
                        className: "object-cover opacity-10 dark:opacity-40"
                    }, void 0, false, {
                        fileName: "[project]/MonTLCN/SocialBook/frontend/src/app/(user)/books/page.tsx",
                        lineNumber: 53,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute inset-0 bg-white/60 dark:bg-[#0f0f0f]/70"
                    }, void 0, false, {
                        fileName: "[project]/MonTLCN/SocialBook/frontend/src/app/(user)/books/page.tsx",
                        lineNumber: 61,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/MonTLCN/SocialBook/frontend/src/app/(user)/books/page.tsx",
                lineNumber: 52,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative z-10",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
                    className: "container mx-auto px-4 md:px-12 py-8",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col md:flex-row justify-between items-end mb-8 border-b border-gray-200 dark:border-white/10 pb-6",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                        className: "text-3xl md:text-4xl font-bold tracking-wide mb-2",
                                        children: "Thư Viện"
                                    }, void 0, false, {
                                        fileName: "[project]/MonTLCN/SocialBook/frontend/src/app/(user)/books/page.tsx",
                                        lineNumber: 68,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-gray-600 dark:text-gray-400",
                                        children: "Khám phá hàng ngàn đầu sách hấp dẫn"
                                    }, void 0, false, {
                                        fileName: "[project]/MonTLCN/SocialBook/frontend/src/app/(user)/books/page.tsx",
                                        lineNumber: 71,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/MonTLCN/SocialBook/frontend/src/app/(user)/books/page.tsx",
                                lineNumber: 67,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/MonTLCN/SocialBook/frontend/src/app/(user)/books/page.tsx",
                            lineNumber: 66,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$components$2f$book$2f$SearchBar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SearchBar"], {
                            initialValue: searchQuery,
                            onSearch: setSearch,
                            onClear: clearSearch
                        }, void 0, false, {
                            fileName: "[project]/MonTLCN/SocialBook/frontend/src/app/(user)/books/page.tsx",
                            lineNumber: 77,
                            columnNumber: 11
                        }, this),
                        searchQuery && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-center text-sm text-gray-600 dark:text-gray-400 mb-6",
                            children: [
                                "Kết quả cho:",
                                ' ',
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "font-bold text-gray-900 dark:text-white",
                                    children: [
                                        '"',
                                        searchQuery,
                                        '"'
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/MonTLCN/SocialBook/frontend/src/app/(user)/books/page.tsx",
                                    lineNumber: 86,
                                    columnNumber: 15
                                }, this),
                                ' ',
                                "(",
                                metaData?.total || 0,
                                " truyện)"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/MonTLCN/SocialBook/frontend/src/app/(user)/books/page.tsx",
                            lineNumber: 84,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col lg:flex-row gap-8 mb-10",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$components$2f$book$2f$FilterSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FilterSection"], {
                                    allGenres: filtersData?.genres || [],
                                    allTags: filtersData?.tags || [],
                                    selectedGenres: genres,
                                    selectedTags: tags,
                                    onToggleGenre: (slug)=>toggleFilter('genres', slug),
                                    onToggleTag: (tag)=>toggleFilter('tags', tag),
                                    onClearGenres: clearGenres
                                }, void 0, false, {
                                    fileName: "[project]/MonTLCN/SocialBook/frontend/src/app/(user)/books/page.tsx",
                                    lineNumber: 94,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$components$2f$book$2f$SortDropdown$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SortDropdown"], {
                                    currentSort: sortBy,
                                    currentOrder: order,
                                    onSortChange: setSort
                                }, void 0, false, {
                                    fileName: "[project]/MonTLCN/SocialBook/frontend/src/app/(user)/books/page.tsx",
                                    lineNumber: 103,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/MonTLCN/SocialBook/frontend/src/app/(user)/books/page.tsx",
                            lineNumber: 93,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$components$2f$book$2f$ActiveFilters$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActiveFilters"], {
                            genres: genres,
                            tags: tags,
                            allGenres: filtersData?.genres || [],
                            onRemoveGenre: (slug)=>toggleFilter('genres', slug),
                            onRemoveTag: (tag)=>toggleFilter('tags', tag),
                            onClearAll: clearFilters
                        }, void 0, false, {
                            fileName: "[project]/MonTLCN/SocialBook/frontend/src/app/(user)/books/page.tsx",
                            lineNumber: 110,
                            columnNumber: 11
                        }, this),
                        isBooksLoading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col items-center justify-center py-20",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "animate-spin rounded-full h-10 w-10 border-b-2 border-red-600"
                            }, void 0, false, {
                                fileName: "[project]/MonTLCN/SocialBook/frontend/src/app/(user)/books/page.tsx",
                                lineNumber: 121,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/MonTLCN/SocialBook/frontend/src/app/(user)/books/page.tsx",
                            lineNumber: 120,
                            columnNumber: 13
                        }, this) : books.length > 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-x-4 gap-y-8",
                            children: books.map((book, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    ref: index === books.length - 1 ? lastBookRef : null,
                                    className: "w-full",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$components$2f$book$2f$BookCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BookCard"], {
                                        book: book
                                    }, void 0, false, {
                                        fileName: "[project]/MonTLCN/SocialBook/frontend/src/app/(user)/books/page.tsx",
                                        lineNumber: 131,
                                        columnNumber: 19
                                    }, this)
                                }, `${book.id}-${index}`, false, {
                                    fileName: "[project]/MonTLCN/SocialBook/frontend/src/app/(user)/books/page.tsx",
                                    lineNumber: 126,
                                    columnNumber: 17
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/MonTLCN/SocialBook/frontend/src/app/(user)/books/page.tsx",
                            lineNumber: 124,
                            columnNumber: 13
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col items-center justify-center py-20 bg-white dark:bg-white/5 rounded-2xl border border-gray-300 dark:border-white/10 mt-8",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "bg-gray-200 dark:bg-white/10 p-4 rounded-full mb-4",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__["Search"], {
                                        size: 32,
                                        className: "text-gray-400"
                                    }, void 0, false, {
                                        fileName: "[project]/MonTLCN/SocialBook/frontend/src/app/(user)/books/page.tsx",
                                        lineNumber: 138,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/MonTLCN/SocialBook/frontend/src/app/(user)/books/page.tsx",
                                    lineNumber: 137,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-xl font-medium mb-2",
                                    children: "Không tìm thấy truyện nào"
                                }, void 0, false, {
                                    fileName: "[project]/MonTLCN/SocialBook/frontend/src/app/(user)/books/page.tsx",
                                    lineNumber: 140,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: clearAll,
                                    className: "px-6 py-2 bg-red-600 hover:bg-red-700 text-white rounded-full transition-colors font-medium",
                                    children: "Xóa tất cả bộ lọc"
                                }, void 0, false, {
                                    fileName: "[project]/MonTLCN/SocialBook/frontend/src/app/(user)/books/page.tsx",
                                    lineNumber: 143,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/MonTLCN/SocialBook/frontend/src/app/(user)/books/page.tsx",
                            lineNumber: 136,
                            columnNumber: 13
                        }, this),
                        isFetchingMore && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex justify-center py-8 gap-2 text-gray-600 dark:text-gray-400",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "animate-spin rounded-full h-6 w-6 border-2 border-red-600 border-t-transparent"
                                }, void 0, false, {
                                    fileName: "[project]/MonTLCN/SocialBook/frontend/src/app/(user)/books/page.tsx",
                                    lineNumber: 154,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    children: "Đang tải thêm sách..."
                                }, void 0, false, {
                                    fileName: "[project]/MonTLCN/SocialBook/frontend/src/app/(user)/books/page.tsx",
                                    lineNumber: 155,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/MonTLCN/SocialBook/frontend/src/app/(user)/books/page.tsx",
                            lineNumber: 153,
                            columnNumber: 13
                        }, this),
                        !hasMore && books.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex justify-center py-8 text-gray-500 dark:text-gray-400",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                children: "Đã hiển thị tất cả sách"
                            }, void 0, false, {
                                fileName: "[project]/MonTLCN/SocialBook/frontend/src/app/(user)/books/page.tsx",
                                lineNumber: 161,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/MonTLCN/SocialBook/frontend/src/app/(user)/books/page.tsx",
                            lineNumber: 160,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/MonTLCN/SocialBook/frontend/src/app/(user)/books/page.tsx",
                    lineNumber: 65,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/MonTLCN/SocialBook/frontend/src/app/(user)/books/page.tsx",
                lineNumber: 64,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/MonTLCN/SocialBook/frontend/src/app/(user)/books/page.tsx",
        lineNumber: 51,
        columnNumber: 5
    }, this);
}
_s(BooksPage, "+xMmlIbm0XUk2Woho/HNiz0VJM0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$features$2f$books$2f$hooks$2f$useBookParams$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBookParams"],
        __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$features$2f$books$2f$api$2f$bookApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGetFiltersQuery"],
        __TURBOPACK__imported__module__$5b$project$5d2f$MonTLCN$2f$SocialBook$2f$frontend$2f$src$2f$features$2f$books$2f$hooks$2f$useBookPagination$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBookPagination"]
    ];
});
_c = BooksPage;
var _c;
__turbopack_context__.k.register(_c, "BooksPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=MonTLCN_SocialBook_frontend_src_0_m1c7k._.js.map