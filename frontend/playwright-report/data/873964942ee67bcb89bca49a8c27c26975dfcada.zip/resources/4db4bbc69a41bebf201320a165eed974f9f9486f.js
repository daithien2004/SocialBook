(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/MonTLCN_SocialBook_frontend_src_0_m1c7k._.js","static/chunks/0.ss_0~~syt8._.js"],
    source: "dynamic"
});
