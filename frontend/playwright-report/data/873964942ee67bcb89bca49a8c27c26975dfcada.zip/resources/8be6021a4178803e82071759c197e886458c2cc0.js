(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_00jog2a._.js","static/chunks/0.ss_next_dist_compiled_next-devtools_index_0idj.vx.js","static/chunks/0.ss_next_dist_compiled_react-dom_038.je-._.js","static/chunks/0.ss_next_dist_compiled_react-server-dom-turbopack_0yjg-y0._.js","static/chunks/0.ss_next_dist_compiled_0_1y-d-._.js","static/chunks/0.ss_next_dist_client_0g8b96n._.js","static/chunks/0.ss_next_dist_0-v4wy4._.js","static/chunks/078f_@swc_helpers_cjs_03e_v~s._.js"],
    source: "entry"
});
